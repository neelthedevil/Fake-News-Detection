import joblib

# Load your trained model and vectorizer
model = joblib.load("lr_model.jb")
vectorizer = joblib.load("vectorizer.jb")

# Sample training data (⚠️ Use the real dataset you trained with!)
X_train = ["Fake article text", "Real article text"]
y_train = [0, 1]

# Transform the training data using the vectorizer
X_transformed = vectorizer.transform(X_train)

# Calculate accuracy
accuracy = model.score(X_transformed, y_train)

# Save accuracy to file
joblib.dump(accuracy, "model_accuracy.jb")
print("✅ model_accuracy.jb saved!")
