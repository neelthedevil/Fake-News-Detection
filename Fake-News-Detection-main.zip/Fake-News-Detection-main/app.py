import streamlit as st
import joblib
import numpy as np
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from PIL import Image
import pytesseract

# 🔹 Load Pre-trained Model & Vectorizer
try:
    vectorizer = joblib.load("vectorizer.jb")
    model = joblib.load("lr_model.jb")
    model_accuracy = joblib.load("model_accuracy.jb")
except FileNotFoundError:
    st.error("❌ Model/vectorizer/accuracy file not found! Ensure all required files exist.")
    st.stop()

# 🔹 Streamlit Page Config
st.set_page_config(page_title="Fake News Detector", page_icon="📰", layout="centered")

# 🔹 Sidebar Navigation
st.sidebar.title("🔀 Navigation")
option = st.sidebar.radio("Select Mode", ["Text-Based Detection", "Image-Based Detection"])

# 🔹 Function to Plot Confidence Gauge Chart
def plot_gauge_chart(value):
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=value * 100,
        title={'text': "Confidence Level"},
        gauge={
            'axis': {'range': [0, 100]},
            'bar': {'color': "blue"},
            'steps': [
                {'range': [0, 50], 'color': '#ff6666'},
                {'range': [50, 75], 'color': '#ffd966'},
                {'range': [75, 100], 'color': '#90ee90'}
            ]
        }
    ))
    st.plotly_chart(fig, use_container_width=True)

# 🔹 Function to Plot Pie Chart
def plot_pie_chart(probabilities):
    labels = ["Fake News", "Real News"]
    colors = ["red", "green"]
    fig, ax = plt.subplots()
    ax.pie(probabilities, labels=labels, autopct='%1.1f%%', colors=colors, startangle=90)
    ax.set_title("Prediction Probability (Pie Chart)")
    st.pyplot(fig)

# 🔹 Function to Plot Bar Chart
def plot_bar_chart(probabilities):
    labels = ["Fake News", "Real News"]
    colors = ["red", "green"]
    fig, ax = plt.subplots()
    ax.bar(labels, probabilities * 100, color=colors)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Confidence (%)")
    ax.set_title("Prediction Probability (Bar Chart)")
    st.pyplot(fig)

# 🔹 Text-Based News Detection
if option == "Text-Based Detection":
    st.title("📰 Fake News Detector (Text-Based)")
    st.write("Enter a news article below to check whether it is **Fake or Real**.")
    
    input_text = st.text_area("📝 News Article:", "")
    
    if st.button("🔍 Check News"):
        if input_text.strip():
            transformed_input = vectorizer.transform([input_text])
            prediction = model.predict(transformed_input)[0]
            probabilities = model.predict_proba(transformed_input)[0]
            confidence = probabilities[prediction]
            
            if prediction == 1:
                st.success(f"✅ The News is **Real**! ({confidence * 100:.2f}% Confidence)")
            else:
                st.error(f"❌ The News is **Fake**! ({confidence * 100:.2f}% Confidence)")
            
            st.info(f"📊 **Model Accuracy:** `{model_accuracy * 100:.2f}%`")
            
            st.subheader("📟 Confidence Meter")
            plot_gauge_chart(confidence)
            plot_pie_chart(probabilities)
            plot_bar_chart(probabilities)
        else:
            st.warning("⚠️ Please enter some text to analyze.")

# 🔹 Image-Based News Detection
elif option == "Image-Based Detection":
    st.title("📰 Fake News Detector (Image-Based)")
    st.write("Upload a news image below to check whether it is **Fake or Real**.")
    
    uploaded_file = st.file_uploader("📤 Upload News Image (JPG, PNG)", type=["jpg", "png"])
    
    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption="🖼️ Uploaded Image", use_column_width=True)
        extracted_text = pytesseract.image_to_string(image)
        
        if extracted_text.strip():
            st.subheader("📜 Extracted News Text:")
            st.write(extracted_text)
            
            transformed_input = vectorizer.transform([extracted_text])
            prediction = model.predict(transformed_input)[0]
            probabilities = model.predict_proba(transformed_input)[0]
            confidence = probabilities[prediction]
            
            if prediction == 1:
                st.success(f"✅ The News is **Real**! ({confidence * 100:.2f}% Confidence)")
            else:
                st.error(f"❌ The News is **Fake**! ({confidence * 100:.2f}% Confidence)")
            
            st.subheader("📟 Confidence Meter")
            plot_gauge_chart(confidence)
            plot_pie_chart(probabilities)
            plot_bar_chart(probabilities)
        else:
            st.warning("⚠️ No text detected in the image. Please upload a clearer image.")

# 🔹 Footer
st.sidebar.markdown("---")
st.sidebar.info("👨‍💻 Developed by JAYARJ")