import streamlit as st
import joblib
import numpy as np
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from PIL import Image
import pytesseract

# 🔹 Load Pre-trained Model, Vectorizer & Accuracy
try:
    vectorizer = joblib.load("vectorizer.jb")
    model = joblib.load("lr_model.jb")
    model_accuracy = joblib.load("model_accuracy.jb")
except FileNotFoundError:
    st.error("❌ Model/vectorizer/accuracy file not found! Ensure all of 'vectorizer.jb', 'lr_model.jb', and 'model_accuracy.jb' exist.")
    st.stop()

# 🔹 Streamlit UI
st.title("📰 Fake News Detector from Image")
st.write("Upload a news image below to check whether it is **Fake or Real**.")

# 🔹 Upload Image
uploaded_file = st.file_uploader("📤 Upload News Image (JPG, PNG)", type=["jpg", "png"])

# 🔹 Process Uploaded Image
if uploaded_file is not None:
    # Display the uploaded image
    image = Image.open(uploaded_file)
    st.image(image, caption="🖼️ Uploaded Image", use_column_width=True)

    # 🔹 Extract Text using OCR
    extracted_text = pytesseract.image_to_string(image)

    if extracted_text.strip():
        st.subheader("📜 Extracted News Text:")
        st.write(extracted_text)

        # 🔹 Predict
        transformed_input = vectorizer.transform([extracted_text])
        prediction = model.predict(transformed_input)[0]
        probabilities = model.predict_proba(transformed_input)[0]

        confidence = probabilities[1] if prediction == 1 else probabilities[0]

        # 🔹 Display Result
        if prediction == 1:
            st.success(f"✅ The News is **Real**! ({confidence * 100:.2f}% Confidence)")
        else:
            st.error(f"❌ The News is **Fake**! ({confidence * 100:.2f}% Confidence)")

        # -----------------------
        # 🔹 Charts
        st.subheader("📊 Prediction Confidence Charts")

        # Bar Chart
        labels = ["Fake News", "Real News"]
        colors = ["red", "green"]

        fig_bar, ax = plt.subplots()
        ax.bar(labels, probabilities * 100, color=colors)
        ax.set_ylim(0, 100)
        ax.set_ylabel("Confidence (%)")
        ax.set_title("Bar Chart - Prediction Probability")
        st.pyplot(fig_bar)

        # Pie Chart
        fig_pie, ax = plt.subplots()
        ax.pie(probabilities, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
        ax.set_title("Pie Chart - Prediction Probability")
        st.pyplot(fig_pie)

        # Gauge Chart (Plotly)
        st.subheader("📟 Confidence Gauge")
        fig_gauge = go.Figure(go.Indicator(
            mode="gauge+number",
            value=confidence * 100,
            title={"text": "Confidence Level"},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": "blue"},
                "steps": [
                    {"range": [0, 50], "color": "#ff6666"},
                    {"range": [50, 75], "color": "#ffd966"},
                    {"range": [75, 100], "color": "#90ee90"},
                ],
            }
        ))
        st.plotly_chart(fig_gauge, use_container_width=True)

        # -----------------------
        # 🔹 Final Accuracy
        st.subheader("📈 Model Performance")
        st.info(f"🧠 Model Accuracy: **{model_accuracy * 100:.2f}%**")

    else:
        st.warning("⚠️ No text detected in the image. Please upload a clearer image.")
