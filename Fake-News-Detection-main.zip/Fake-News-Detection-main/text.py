import streamlit as st
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Conv1D, GlobalMaxPooling1D, Dense

# App UI Setup
st.set_page_config(page_title="Fake News Detector", page_icon="🧠", layout="centered")
st.title("📰 Fake News Detector using CNN")
st.markdown("Train the model with your own news examples and test it!")

# Session State to Store Training Data
if "train_texts" not in st.session_state:
    st.session_state.train_texts = []
    st.session_state.train_labels = []
    st.session_state.model_trained = False

# Input for Training
st.header("🔧 Add Training Data")
news_input = st.text_area("Enter News Article:")
label_input = st.radio("Is it Real or Fake?", ("Real (1)", "Fake (0)"))

if st.button("Add to Training Data"):
    if news_input.strip() == "":
        st.warning("Please enter a news article first.")
    else:
        st.session_state.train_texts.append(news_input)
        st.session_state.train_labels.append(1 if label_input.startswith("Real") else 0)
        st.success("News added to training data!")

# Show current training data
if st.session_state.train_texts:
    st.write("🧾 **Training Articles So Far:**")
    for i, (text, label) in enumerate(zip(st.session_state.train_texts, st.session_state.train_labels)):
        st.write(f"{i+1}. {'Real' if label == 1 else 'Fake'}: {text}")

# Train the model
if st.button("🚀 Train Model"):
    if len(st.session_state.train_texts) < 2:
        st.warning("Please add at least 2 news articles to train.")
    else:
        max_words = 1000
        max_len = 50

        tokenizer = Tokenizer(num_words=max_words)
        tokenizer.fit_on_texts(st.session_state.train_texts)
        X = tokenizer.texts_to_sequences(st.session_state.train_texts)
        X = pad_sequences(X, maxlen=max_len)
        y = np.array(st.session_state.train_labels)

        model = Sequential([
            Embedding(input_dim=max_words, output_dim=50, input_length=max_len),
            Conv1D(64, 5, activation='relu'),
            GlobalMaxPooling1D(),
            Dense(10, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
        model.fit(X, y, epochs=5, verbose=0)

        st.session_state.tokenizer = tokenizer
        st.session_state.model = model
        st.session_state.max_len = max_len
        st.session_state.model_trained = True
        st.success("✅ Model trained successfully!")

# Prediction section
st.header("🧪 Test the News")
test_news = st.text_area("Enter a news article to check:", key="test_news")

if st.button("🔍 Check If Real or Fake"):
    if not st.session_state.model_trained:
        st.warning("Please train the model first.")
    elif test_news.strip() == "":
        st.warning("Please enter a news article to test.")
    else:
        seq = st.session_state.tokenizer.texts_to_sequences([test_news])
        padded = pad_sequences(seq, maxlen=st.session_state.max_len)
        prediction = st.session_state.model.predict(padded)[0][0]

        label = "🟢 Real News" if prediction > 0.5 else "🔴 Fake News"
        confidence = prediction if prediction > 0.5 else 1 - prediction

        st.subheader(f"Prediction: {label}")
        st.write(f"🧠 Confidence: **{confidence*100:.2f}%**")
